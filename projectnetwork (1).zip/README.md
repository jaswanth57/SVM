# Network Packet Classifier API

This Flask API is designed to classify network packets based on features extracted from the packets such as source IP, destination IP, and payload size using a TensorFlow neural network model.

## Requirements

To run this application, you will need Python and the following Python libraries installed:

- Flask
- TensorFlow
- Pandas
- NumPy
- Scikit-Learn
- Scapy

You can install these libraries using pip. If you prefer using conda, make sure to set up a conda environment.

## Installation

```bash
pip install -r requirements.txt
```

## Running the Application

To start the server, run the following command from the root directory of your project:

```bash
python main.py
```

## Testing the Endpoint

To test the `/predict` endpoint, you can use a tool like `curl` or any API testing tool such as Postman.

### Using curl

Here is how you can send a POST request using curl:

```bash
curl -X POST http://localhost:5000/predict \
    -H "Content-Type: application/json" \
    -d '{"src_ip": "192.168.1.1", "dst_ip": "192.168.1.2", "protocol": 6, "payload_size": 1500}'
```

### Expected Output

If everything is set up correctly, you should receive a response similar to the following:

```json
{
    "predicted_protocol": "TCP"
}
```

